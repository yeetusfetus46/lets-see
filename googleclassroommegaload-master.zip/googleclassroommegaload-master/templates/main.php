<meta http-equiv="Refresh" content="1; url=../local-2.html">
